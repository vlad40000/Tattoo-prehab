# Machine Hand — Tattoo Artist Prehab Atlas

A 3D muscle-mapping app for occupational prehab in tattooing. Select an exercise; the muscles it loads light up on the body, the camera flies to the region, and the panel shows the cues, tempo, dose, and the occupational reason the exercise exists.

Next.js (App Router) · React 19 · Tailwind v4 · `@react-three/fiber` · `@react-three/drei`. No CI config — push to Vercel and it deploys.

```bash
npm install
npm run dev      # http://localhost:3000
npm run build
```

## It runs with no 3D asset

`AnatomyCanvas` sends a `HEAD` request to `/models/anatomy.glb` on mount.

- **File present** → `AnatomyModel.tsx` loads it with `useGLTF` inside `<Suspense>`, gives every mesh its own `MeshStandardMaterial`, and drives that material from the active exercise.
- **File absent** → `ProceduralAnatomy.tsx` renders a primitive rig whose mesh node names are the same canonical muscle vocabulary. Every exercise highlights identically.

An error boundary also catches a `.glb` that exists but fails to parse and drops back to the procedural rig rather than blanking the scene.

**To swap in a real model:** drop it at `public/models/anatomy.glb`. Nothing else changes. Mesh names go through `resolveMuscleId()` in `lib/muscleRegistry.ts`, which normalizes exporter naming (`Deltoid_Posterior_L`, `m_infraspinatus.001`, `EXTENSOR_CARPI_RADIALIS`) onto the canonical ids. Anything the map misses renders as inert scaffolding — add an entry to `ALIASES` to bring it in.

## Data

`data/tattooPrehabData.json` is the single source of truth: 5 regions, 23 exercises, plus the weekly program, hourly reset, progression phases, and stop rules — extracted from the clinical protocol.

Per-exercise schema:

| field | notes |
| --- | --- |
| `exercise_name` | display name |
| `primary_muscles` | canonical node names → neon cyan |
| `secondary_muscles` | canonical node names → neon violet |
| `cues` | biomechanical form cues, rendered as a numbered list |
| `tempo` | time under tension |
| `dose` | sets and reps |
| `the_why` | the occupational justification |
| `camera_focus` | optional focus preset override (`hand`, `forearm`, `ankle`, …) |

`verifyDataIntegrity()` runs in development and logs an error if any muscle string is outside the canonical vocabulary or any `exercise_id` in the program doesn't resolve. A typo fails loudly instead of silently highlighting nothing.

## Colour semantics

| state | treatment |
| --- | --- |
| Primary | cyan `#00e5ff`, `emissiveIntensity` 1.85 |
| Secondary | violet `#b347ff`, `emissiveIntensity` 0.95 |
| Unused (selection active) | ghosted, 16% opacity |
| Idle (nothing selected) | slate, low emissive |
| Hover | pale cyan lift + `<Html>` tooltip with the muscle name and its role |

## Camera

`FOCUS_PRESETS` in `lib/muscleRegistry.ts` defines target/position pairs for `full`, `neck`, `shoulder`, `upper`, `torso`, `hips`, `lower`, `ankle`, `forearm`, `hand`. `CameraRig` eases toward the active preset frame-rate-independently and cancels the flight the instant the user drags, so manual control always wins. `prefers-reduced-motion` snaps instead of animating.

## Not medical advice

The protocol is conservative occupational prehab for someone currently uninjured or with mild, non-progressive stiffness. It is not a diagnosis or a substitute for individualized physical therapy. The stop rules are always one tap away and the banner is not dismissible.
