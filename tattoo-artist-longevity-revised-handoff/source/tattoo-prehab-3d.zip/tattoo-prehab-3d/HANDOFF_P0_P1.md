# Handoff — Machine Hand / Tattoo Prehab

**State:** P0 complete and verified. P1 blocked on six decisions below.
**Gate command:** `npm run check` (parity → typecheck → lint). All three green.

---

## Gate 0 — reproduce before changing anything

```bash
npm install
npm run verify     # must print "parity holds", exit 0
npm run check      # parity + tsc --noEmit + eslint, all clean
npm run build      # runs verify first, then next build
npx next start -p 3000
```

Then confirm by eye:

1. Sidebar → **Regions** → §5 shows **7** exercises (not 5). Thoracic Extension and Incline Push-Up Plus are new.
2. Sidebar → **Workday** → pre-session routine starts with **90/90 Breathing Reset** and has 8 items.
3. Sidebar → **Program** → Phase 2 reads **Weeks 5–8** (not 3–6). Phase 3 shows Phase 2's sessions with an inheritance note.
4. Select *Eccentric Dumbbell Wrist Extension* → detail panel shows an orange **"Not before precision work"** chip; the sidebar row shows a **grip** badge.
5. Resize to 1024px wide → rail collapses to a closed drawer, model keeps ~992×752, safety banner still visible at the bottom.
6. Open Stop rules → Tab cycles inside the dialog only; Esc closes; focus returns to the button that opened it.

If any of these fail, stop — the dataset or the build is not what this document describes.

---

## KEEP

- `data/protocol.v2.json` — **the authority.** 33 exercises, full manual coverage.
- `scripts/verify-protocol.mjs` — the parity gate. Wired into `build`. Do not weaken it to make a change pass.
- `lib/muscleRegistry.ts` — canonical vocabulary (59 nodes) + `resolveMuscleId()` alias resolution for real `.glb` mesh names.
- `lib/proceduralRig.ts` — zero-asset fallback. 59/59 nodes have geometry.
- The GLB probe + error boundary in `AnatomyCanvas.tsx`. It is why this deploys with no binary asset.

## FIXED (this pass)

| Was | Now |
| --- | --- |
| 23 exercises | 33, every manual §5.1–§9.7 mapped, verified by `manual_ref` round-trip |
| Phases 1-2 / 3-6 / 7-12 | 1-4 / 5-8 / 9-12 per manual |
| "three sessions per week" | "two or three", manual wording |
| Warm-up led with Dead Bug, no hip hinge | 90/90 Breathing first, hip hinge present, 8 items |
| Binary stop-list | Green/Yellow/Red triage with per-zone action + `blocks_progression` |
| No regression/progression/best-use | All three in schema and rendered |
| No ergonomics, symptoms, checklists, refs | All present in dataset; ergonomics + checklists not yet rendered (see D3) |
| `maximumScale: 1` | removed — pinch-zoom restored |
| 30px controls | 44px min |
| 9–10px type | 11px floor |
| Safety banner `display:none` under 1024px | full-width, still visible |
| Sidebar+panel covered the model under 1024px | rail is a closed overlay drawer; model keeps ~60% |
| Modal focused but never trapped/restored | full trap + restore |
| Canvas silently inaccessible | marked `aria-hidden`; all muscle data has a text equivalent in the panel; primary/secondary now carry a **1/2** glyph, not colour alone |
| No lockfile | `package-lock.json` committed |
| `next lint` (interactive, deprecated) | flat `eslint.config.mjs` + `npm run lint` |

## REMOVE

- `lib/prehab.ts` is now a deprecation shim re-exporting `lib/protocol.ts`. Delete it once nothing imports it.
- `data/tattooPrehabData.json` (v1) — kept only for diffing. Delete after D1 is answered.

---

## The one thing worth arguing about

The review's thesis — *"the 3D view should support the workflow, not be the workflow"* — is correct, and it changes what this product is. The original brief was a 3D muscle-mapping app. The review describes a workday companion app with guided timers, local persistence, and offline support, in which the 3D atlas is a subordinate "Learn" tab.

That is the right product. It is not an iteration of the current one. Roughly: guided sessions ≈ a new app shell, persistence ≈ a new state layer, PWA + e2e ≈ new infrastructure. The 3D work already done survives as one tab.

Decide that consciously rather than letting it happen through the backlog.

---

## Blocking decisions

**D1 — Is v1 dead?** Delete `tattooPrehabData.json` and `lib/prehab.ts` now, or keep the shim through the P1 pivot?

**D2 — Product scope.** Build the Prepare / Reset / Recover / Strength / Workstation shell (review's P1), or stay an atlas and stop at correct content? Everything downstream depends on this.

**D3 — Where does non-exercise content render?** Ergonomics (6 sections), symptom modifications (8), and checklists (4) are all in the dataset and currently unrendered. Options: (a) new sidebar tabs, (b) they only appear inside the guided flows from D2, (c) a separate `/manual` route.

**D4 — Persistence substrate.** Review says local-first. Options: `localStorage` (note: forbidden in Claude artifacts, fine in real Next.js), IndexedDB, or Neon following your existing DB-mediated state pattern. Local-first + optional sync is the middle path but doubles the work.

**D5 — Anatomy model.** Procedural rig is placeholder-quality and I said so at delivery. Z-Anatomy (Blender, CC-BY-SA, derived from BodyParts3D) is the most likely licensed source with per-muscle named meshes — **verify the current licence terms before committing**, I'm working from pre-cutoff knowledge. Alternatives: commission it, or buy a commercial anatomy asset. Until one exists, `resolveMuscleId()`'s alias table is unverifiable.

**D6 — Symptom entry point.** §11 supports "I hurt here → workstation fix + exercise emphasis + camera focus". The data is modelled (`symptom_modifications`, with `emphasize`/`reduce` cross-checked so nothing is both). Ship it as a first-class navigation mode, or bury it in the manual view?

---

## What I would do next, in order

1. Answer D2. Nothing else is safe to build first.
2. If D2 = pivot: build the session runner against `routines[]` and `program.phases[].sessions[]` — both already carry `prescription` strings per item, so the runner needs no new data.
3. Add the traffic-light check as a *write* (currently read-only): a post-session green/yellow/red that feeds `blocks_progression`. That makes the manual's 24-hour rule enforceable instead of advisory.
4. e2e at 1024×1366 and 1366×1024. My layout numbers are computed, not visually confirmed — no browser in the build environment.

---

## Notes for whoever picks this up

- `hand_fatigue` is **my addition**, not the manual's — it makes the grip rule machine-checkable. The gate fails the build if a flagged exercise appears in the pre-session routine or claims `pre_session`. Nine exercises are flagged.
- Phase 3 deliberately has `sessions: []` and `inherits_sessions_from: "phase-2"`. The manual states Phase 3 *rules* but never restates session contents. Do not invent prescriptions to fill it; `sessionsForPhase()` resolves the link.
- The parity gate holds a hand-transcribed `MANUAL` constant. It is the second copy of the manual's facts, deliberately — if the dataset and that constant disagree, that disagreement *is* the bug. Mutation-tested against five fault classes (dropped exercise, phase drift, muscle typo, reference renumbering, grip-rule violation); all five caught.
- Five muscle nodes render but are never highlighted by any exercise (decorative). That is expected, and the gate reports the count so it stays visible.
