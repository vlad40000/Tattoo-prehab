'use client';

import { useEffect, useState } from 'react';
import { labelFor } from '@/lib/muscleRegistry';
import {
  BEST_USE_LABELS,
  findExercise,
  protocol,
  regions,
  routines,
  sessionsForPhase,
  type Exercise,
  type Region,
} from '@/lib/protocol';
import { SafetyBanner, SafetyModal } from './SafetyModal';

type Props = {
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  activeRegionId: string;
  onRegionChange: (id: string) => void;
};

type SidebarMode = 'regions' | 'routines' | 'program';

const MODES: { id: SidebarMode; label: string }[] = [
  { id: 'regions', label: 'Regions' },
  { id: 'routines', label: 'Workday' },
  { id: 'program', label: 'Program' },
];

export default function UIOverlay({ selectedId, onSelect, activeRegionId, onRegionChange }: Props) {
  const [mode, setMode] = useState<SidebarMode>('regions');
  const [safetyOpen, setSafetyOpen] = useState(false);
  // The rail overlays the model below 1280px, so it must not start open there.
  const [sidebarOpen, setSidebarOpen] = useState(true);
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 1279px)');
    const sync = () => setSidebarOpen(!mq.matches);
    sync();
    mq.addEventListener('change', sync);
    return () => mq.removeEventListener('change', sync);
  }, []);

  const exercise = findExercise(selectedId);
  const region = regions.find((r) => r.id === activeRegionId) ?? regions[0];

  const pick = (id: string) => {
    const owner = regions.find((r) => r.exercises.some((e) => e.id === id));
    if (owner) onRegionChange(owner.id);
    onSelect(selectedId === id ? null : id);
  };

  return (
    <>
      <header className="topbar">
        <button
          type="button"
          className="icon-btn icon-btn--ghost sidebar-toggle"
          onClick={() => setSidebarOpen((v) => !v)}
          aria-expanded={sidebarOpen}
          aria-controls="protocol-rail"
        >
          <span aria-hidden>{sidebarOpen ? '×' : '☰'}</span>
          <span className="sr-only">{sidebarOpen ? 'Hide protocol list' : 'Show protocol list'}</span>
        </button>
        <div className="topbar__mark">
          <span className="topbar__glyph" aria-hidden />
          <div>
            <p className="eyebrow">Occupational prehab · tattoo</p>
            <h1 className="topbar__title">Machine Hand</h1>
          </div>
        </div>
        <button type="button" className="btn-warn" onClick={() => setSafetyOpen(true)}>
          Stop rules
        </button>
      </header>

      <aside
        id="protocol-rail"
        className={`sidebar glass ${sidebarOpen ? '' : 'sidebar--closed'}`}
        aria-label="Protocol navigation"
      >
        <div className="seg" role="tablist">
          {MODES.map((m) => (
            <button
              key={m.id}
              type="button"
              role="tab"
              aria-selected={mode === m.id}
              className={`seg__btn ${mode === m.id ? 'is-active' : ''}`}
              onClick={() => setMode(m.id)}
            >
              {m.label}
            </button>
          ))}
        </div>

        {mode === 'regions' && (
          <RegionList
            activeRegionId={activeRegionId}
            selectedId={selectedId}
            onRegionChange={onRegionChange}
            onSelect={onSelect}
          />
        )}
        {mode === 'routines' && <RoutineList selectedId={selectedId} onPick={pick} />}
        {mode === 'program' && <ProgramList selectedId={selectedId} onPick={pick} />}
      </aside>

      <section className="infopanel glass" aria-live="polite" aria-label="Exercise detail">
        {exercise ? (
          <ExerciseDetail exercise={exercise} region={region} onClear={() => onSelect(null)} />
        ) : (
          <RegionBrief region={region} />
        )}
      </section>

      <div className="banner-slot">
        <SafetyBanner onOpen={() => setSafetyOpen(true)} />
      </div>

      <SafetyModal open={safetyOpen} onClose={() => setSafetyOpen(false)} />
    </>
  );
}

/* ------------------------------------------------------------------ */

function ExButton({
  ex,
  detail,
  active,
  onClick,
}: {
  ex: Exercise;
  detail: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button type="button" className={`exlist__btn ${active ? 'is-active' : ''}`} onClick={onClick}>
      <span className="exlist__name">
        {ex.exercise_name}
        {ex.hand_fatigue && (
          <span className="grip-flag" title="Loads the grip — not before precision work">
            grip
          </span>
        )}
      </span>
      <span className="exlist__dose">{detail}</span>
    </button>
  );
}

function RegionList({
  activeRegionId,
  selectedId,
  onRegionChange,
  onSelect,
}: {
  activeRegionId: string;
  selectedId: string | null;
  onRegionChange: (id: string) => void;
  onSelect: (id: string | null) => void;
}) {
  return (
    <nav className="scroll-area">
      {regions.map((region) => {
        const open = region.id === activeRegionId;
        return (
          <div key={region.id} className="regionblock" style={{ ['--accent' as string]: region.accent }}>
            <button
              type="button"
              className={`regionblock__head ${open ? 'is-open' : ''}`}
              onClick={() => onRegionChange(region.id)}
              aria-expanded={open}
            >
              <span className="regionblock__num">§{region.manual_ref}</span>
              <span className="regionblock__name">{region.name}</span>
              <span className="regionblock__count">{region.exercises.length}</span>
            </button>

            {open && (
              <ul className="exlist">
                {region.exercises.map((ex) => (
                  <li key={ex.id}>
                    <ExButton
                      ex={ex}
                      detail={ex.dose}
                      active={selectedId === ex.id}
                      onClick={() => onSelect(selectedId === ex.id ? null : ex.id)}
                    />
                  </li>
                ))}
              </ul>
            )}
          </div>
        );
      })}
    </nav>
  );
}

function RoutineList({ selectedId, onPick }: { selectedId: string | null; onPick: (id: string) => void }) {
  return (
    <div className="scroll-area">
      {routines.map((routine) => (
        <div key={routine.id} className="regionblock regionblock--session">
          <div className="session__head">
            <span className="session__day">{routine.duration_min} min</span>
            <span className="session__label">{routine.name}</span>
          </div>
          <p className="hint hint--tight">{routine.when}</p>
          {routine.warning && <p className="callout callout--warn">{routine.warning}</p>}
          <ul className="exlist">
            {routine.items.map((item, i) => {
              const ex = findExercise(item.exercise_id);
              if (!ex) return null;
              return (
                <li key={`${item.exercise_id}-${i}`}>
                  <ExButton
                    ex={ex}
                    detail={item.prescription}
                    active={selectedId === ex.id}
                    onClick={() => onPick(ex.id)}
                  />
                </li>
              );
            })}
          </ul>
          {routine.steps && (
            <ul className="rule-list rule-list--compact">
              {routine.steps.map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ul>
          )}
        </div>
      ))}
    </div>
  );
}

function ProgramList({ selectedId, onPick }: { selectedId: string | null; onPick: (id: string) => void }) {
  const { program } = protocol;

  return (
    <div className="scroll-area">
      <p className="hint">{program.note}</p>

      {program.phases.map((phase) => {
        const sessions = sessionsForPhase(phase);
        return (
          <div key={phase.id} className="regionblock regionblock--session">
            <div className="session__head">
              <span className="session__day">
                Wk {phase.weeks[0]}-{phase.weeks[1]}
              </span>
              <span className="session__label">{phase.name}</span>
            </div>
            <ul className="rule-list rule-list--compact">
              {phase.rules.map((r) => (
                <li key={r}>{r}</li>
              ))}
            </ul>
            {phase.inherit_note && <p className="callout">{phase.inherit_note}</p>}

            {sessions.map((session) => (
              <div key={`${phase.id}-${session.id}`} className="subsession">
                <p className="subsession__label">
                  {session.label}
                  {session.optional && <span className="subsession__opt">optional</span>}
                </p>
                <ul className="exlist">
                  {session.items.map((item, i) => {
                    const ex = findExercise(item.exercise_id);
                    if (!ex) return null;
                    return (
                      <li key={`${item.exercise_id}-${i}`}>
                        <ExButton
                          ex={ex}
                          detail={item.prescription}
                          active={selectedId === ex.id}
                          onClick={() => onPick(ex.id)}
                        />
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
          </div>
        );
      })}

      <div className="regionblock regionblock--session">
        <div className="session__head">
          <span className="session__day">Back off</span>
          <span className="session__label">Reduce volume when</span>
        </div>
        <ul className="rule-list rule-list--compact">
          {program.reduce_volume_when.map((s) => (
            <li key={s}>{s}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function RegionBrief({ region }: { region: Region }) {
  return (
    <div className="detail" style={{ ['--accent' as string]: region.accent }}>
      <p className="eyebrow eyebrow--accent">Manual §{region.manual_ref}</p>
      <h2 className="detail__title">{region.name}</h2>

      <div className="detail__block">
        <h3 className="section-label">Training objective</h3>
        <p className="detail__body">{region.objective}</p>
      </div>

      {region.warning && (
        <div className="detail__block">
          <p className="callout callout--warn">{region.warning}</p>
        </div>
      )}

      <p className="hint">Pick an exercise to light up the muscles it loads.</p>
    </div>
  );
}

function ExerciseDetail({
  exercise,
  region,
  onClear,
}: {
  exercise: Exercise;
  region: Region;
  onClear: () => void;
}) {
  return (
    <div className="detail" style={{ ['--accent' as string]: region.accent }}>
      <div className="detail__head">
        <div>
          <p className="eyebrow eyebrow--accent">
            {region.short_name} · §{exercise.manual_ref}
          </p>
          <h2 className="detail__title">{exercise.exercise_name}</h2>
        </div>
        <button type="button" className="icon-btn icon-btn--ghost" onClick={onClear}>
          <span aria-hidden>×</span>
          <span className="sr-only">Clear selection</span>
        </button>
      </div>

      <div className="usebar">
        {exercise.best_use.map((u) => (
          <span key={u} className="usechip">
            {BEST_USE_LABELS[u]}
          </span>
        ))}
        {exercise.hand_fatigue && <span className="usechip usechip--warn">Not before precision work</span>}
      </div>
      {exercise.pre_session_note && <p className="hint hint--tight">Pre-session: {exercise.pre_session_note}</p>}

      <dl className="statgrid">
        <div>
          <dt>Tempo</dt>
          <dd>{exercise.tempo}</dd>
        </div>
        <div>
          <dt>Dose</dt>
          <dd>{exercise.dose}</dd>
        </div>
      </dl>

      <div className="detail__block">
        <h3 className="section-label">Setup</h3>
        <p className="detail__body">{exercise.setup}</p>
        {exercise.equipment.length > 0 && (
          <div className="chips chips--tight">
            {exercise.equipment.map((eq) => (
              <span key={eq} className="chip chip--kit">
                {eq}
              </span>
            ))}
          </div>
        )}
      </div>

      <div className="detail__block">
        <h3 className="section-label">Muscles under load</h3>
        <div className="chips">
          {exercise.primary_muscles.map((m) => (
            <span key={m} className="chip chip--primary">
              <span className="chip__role" aria-hidden>
                1
              </span>
              {labelFor(m)}
              <span className="sr-only"> (primary)</span>
            </span>
          ))}
          {exercise.secondary_muscles.map((m) => (
            <span key={m} className="chip chip--secondary">
              <span className="chip__role" aria-hidden>
                2
              </span>
              {labelFor(m)}
              <span className="sr-only"> (secondary)</span>
            </span>
          ))}
        </div>
      </div>

      <div className="detail__block">
        <h3 className="section-label">Form cues</h3>
        <ol className="cuelist">
          {exercise.cues.map((c) => (
            <li key={c}>{c}</li>
          ))}
        </ol>
      </div>

      <div className="detail__block">
        <h3 className="section-label">Scale it</h3>
        <div className="scale">
          <div className="scale__row">
            <span className="scale__tag scale__tag--down">Easier</span>
            <p>{exercise.regression}</p>
          </div>
          <div className="scale__row">
            <span className="scale__tag scale__tag--up">Harder</span>
            <p>{exercise.progression}</p>
          </div>
        </div>
      </div>

      <div className="detail__block detail__block--why">
        <h3 className="section-label">Why a tattoo artist does this</h3>
        <p className="detail__body">{exercise.the_why}</p>
      </div>
    </div>
  );
}
