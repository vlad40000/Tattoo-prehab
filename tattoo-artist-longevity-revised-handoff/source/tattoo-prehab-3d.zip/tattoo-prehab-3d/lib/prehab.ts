/** @deprecated v1 shim. Import from '@/lib/protocol' instead. Removed once all callers migrate. */
export * from './protocol';
export { protocol as prehabData } from './protocol';
