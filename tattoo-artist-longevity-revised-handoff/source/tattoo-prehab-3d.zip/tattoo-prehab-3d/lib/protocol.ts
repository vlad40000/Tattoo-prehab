import raw from '@/data/protocol.v2.json';
import { MUSCLE_LABELS, type FocusKey, type MuscleId } from './muscleRegistry';

export type BestUse = 'pre_session' | 'session_reset' | 'strength' | 'post_work' | 'recovery';

export const BEST_USE_LABELS: Record<BestUse, string> = {
  pre_session: 'Pre-session',
  session_reset: 'Session reset',
  strength: 'Strength day',
  post_work: 'After work',
  recovery: 'Recovery day',
};

export type Exercise = {
  id: string;
  manual_ref: string;
  exercise_name: string;
  type: 'strength' | 'mobility' | 'breathing';
  equipment: string[];
  setup: string;
  primary_muscles: string[];
  secondary_muscles: string[];
  cues: string[];
  tempo: string;
  dose: string;
  best_use: BestUse[];
  pre_session_note?: string;
  regression: string;
  progression: string;
  the_why: string;
  camera_focus: FocusKey;
  /** True when the exercise loads the grip enough to compromise same-day precision work. */
  hand_fatigue: boolean;
};

export type Region = {
  id: string;
  index: number;
  manual_ref: string;
  name: string;
  short_name: string;
  accent: string;
  camera_focus: FocusKey;
  objective: string;
  refs: number[];
  warning?: string;
  exercises: Exercise[];
};

export type TriageZone = {
  id: 'green' | 'yellow' | 'red';
  label: string;
  color: string;
  looks_like: string;
  action: string;
  blocks_progression: boolean;
  halts_session?: boolean;
};

export type RoutineItem = { exercise_id: string; prescription: string; alternatives?: string[] };

export type Routine = {
  id: string;
  name: string;
  duration_min: number;
  when: string;
  warning?: string;
  lead_in?: string;
  steps?: string[];
  items: RoutineItem[];
};

export type Phase = {
  id: string;
  name: string;
  weeks: [number, number];
  rules: string[];
  inherits_sessions_from?: string;
  inherit_note?: string;
  sessions: { id: string; label: string; optional?: boolean; items: RoutineItem[] }[];
};

export type SymptomModification = {
  id: string;
  symptom: string;
  region_id: string | null;
  severity?: 'referral';
  workstation: string;
  emphasize: string[];
  emphasize_note: string | null;
  reduce: string[];
  reduce_note: string | null;
};

export type Checklist = {
  id: string;
  name: string;
  cadence: string;
  type?: 'questions';
  items: string[];
};

export type Protocol = {
  schema_version: string;
  source: { document: string; document_version: string; prepared: string; authority: string; supersedes: string };
  meta: Record<string, unknown> & {
    title: string;
    subtitle: string;
    scope: string;
    not_scope: string;
    controlling_principle: string;
    exercise_is_support: string;
    final_operating_principle: string;
    how_to_use: string[];
    equipment: string[];
  };
  occupational_demands: {
    summary: string;
    five_load_model: { id: string; name: string; detail: string }[];
    research_findings: { claim: string; refs: number[] }[];
  };
  triage: {
    name: string;
    zones: TriageZone[];
    effort_standard: string[];
    twenty_four_hour_rule: string;
    progression_hierarchy: string[];
    immediate_stop: string[];
    prompt_evaluation: string[];
    referral_indicators: string[];
    load_rule: string;
    grip_rule: string;
  };
  ergonomics: {
    principle: string;
    refs: number[];
    audit_question: string;
    sections: { id: string; ref: string; name: string; points: string[] }[];
    workstation_checklist: string[];
  };
  routines: Routine[];
  regions: Region[];
  program: {
    name: string;
    note: string;
    refs: number[];
    weekly_template: { day: string; plan: string; emphasis: string }[];
    phases: Phase[];
    maintenance: { name: string; rules: string[] };
    minimum_effective_session: { name: string; duration_min: number; items: RoutineItem[] };
    reduce_volume_when: string[];
  };
  symptom_modifications: SymptomModification[];
  checklists: Checklist[];
  log_schema: {
    id: string;
    name: string;
    cadence: string;
    fields: { key: string; label: string; type: string; min?: number; max?: number }[];
  };
  evidence: {
    statement: string;
    notes: string[];
    references: { n: number; citation: string }[];
  };
};

export const protocol = raw as unknown as Protocol;
export const regions = protocol.regions;
export const routines = protocol.routines;
export const allExercises: Exercise[] = regions.flatMap((r) => r.exercises);

const index = new Map(allExercises.map((e) => [e.id, e]));

export function findExercise(id: string | null | undefined): Exercise | null {
  return id ? (index.get(id) ?? null) : null;
}

export function regionOf(exerciseId: string): Region | null {
  return regions.find((r) => r.exercises.some((e) => e.id === exerciseId)) ?? null;
}

/** Exercises usable in a given context, honouring the manual's grip rule. */
export function exercisesFor(use: BestUse): Exercise[] {
  return allExercises.filter((e) => e.best_use.includes(use));
}

/** Which phase covers a given program week. */
export function phaseForWeek(week: number): Phase | null {
  return protocol.program.phases.find((p) => week >= p.weeks[0] && week <= p.weeks[1]) ?? null;
}

/** Phase 3 declares no sessions of its own; resolve through the inheritance link. */
export function sessionsForPhase(phase: Phase): Phase['sessions'] {
  if (!phase.inherits_sessions_from) return phase.sessions;
  const parent = protocol.program.phases.find((p) => p.id === phase.inherits_sessions_from);
  return parent ? parent.sessions : [];
}

export type MuscleState = { primary: string[]; secondary: string[] };
export const EMPTY_MUSCLE_STATE: MuscleState = { primary: [], secondary: [] };

export function muscleStateFor(exercise: Exercise | null): MuscleState {
  return exercise
    ? { primary: exercise.primary_muscles, secondary: exercise.secondary_muscles }
    : EMPTY_MUSCLE_STATE;
}

/** Dev-time guard. The full gate is scripts/verify-protocol.mjs. */
export function verifyDataIntegrity(): string[] {
  const problems: string[] = [];
  const known = new Set(Object.keys(MUSCLE_LABELS) as MuscleId[]);
  for (const region of regions) {
    for (const ex of region.exercises) {
      for (const m of [...ex.primary_muscles, ...ex.secondary_muscles]) {
        if (!known.has(m as MuscleId)) problems.push(`${region.id}/${ex.id}: unknown muscle "${m}"`);
      }
      if (ex.hand_fatigue && ex.best_use.includes('pre_session')) {
        problems.push(`${ex.id}: violates the grip rule (hand_fatigue + pre_session)`);
      }
    }
  }
  return problems;
}
