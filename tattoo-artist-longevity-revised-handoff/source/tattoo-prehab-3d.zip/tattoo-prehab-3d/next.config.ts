import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // three.js ships untranspiled ESM examples; Next handles this natively,
  // but drei pulls a few packages that benefit from explicit transpilation.
  transpilePackages: ['three'],
};

export default nextConfig;
