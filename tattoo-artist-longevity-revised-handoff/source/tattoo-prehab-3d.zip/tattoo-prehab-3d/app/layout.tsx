import type { Metadata, Viewport } from 'next';
import { Inter, JetBrains_Mono, Space_Grotesk } from 'next/font/google';
import './globals.css';

const display = Space_Grotesk({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  variable: '--font-display',
  display: 'swap',
});

const ui = Inter({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-ui',
  display: 'swap',
});

const mono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '600'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Machine Hand — Tattoo Artist Prehab Atlas',
  description:
    'A 3D muscle map of the occupational prehab protocol for tattoo artists: what each exercise loads, how to do it, and why the job demands it.',
};

export const viewport: Viewport = {
  themeColor: '#02060f',
  width: 'device-width',
  initialScale: 1,
  // No maximumScale / user-scalable lock: pinch-zoom is a WCAG 1.4.4
  // requirement and this app is read at arm's length on a shop iPad.
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${ui.variable} ${mono.variable}`}>
      <body>{children}</body>
    </html>
  );
}
