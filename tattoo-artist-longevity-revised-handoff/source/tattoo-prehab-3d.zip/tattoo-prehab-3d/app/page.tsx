'use client';

import { useMemo, useState } from 'react';
import AnatomyCanvas from '@/components/AnatomyCanvas';
import UIOverlay from '@/components/UIOverlay';
import { findExercise, muscleStateFor, regions } from '@/lib/protocol';
import type { FocusKey } from '@/lib/muscleRegistry';

export default function Page() {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [activeRegionId, setActiveRegionId] = useState<string>(regions[0].id);
  const [interacted, setInteracted] = useState(false);

  const exercise = findExercise(selectedId);
  const region = regions.find((r) => r.id === activeRegionId) ?? regions[0];

  const muscleState = useMemo(() => muscleStateFor(exercise), [exercise]);

  // Selecting a hand/wrist exercise flies the camera to the forearm; a region
  // on its own frames that region; an untouched app shows the whole body.
  const focus: FocusKey = exercise?.camera_focus ?? (interacted ? region.camera_focus : 'full');

  return (
    <main>
      <AnatomyCanvas muscleState={muscleState} focus={focus} />
      <UIOverlay
        selectedId={selectedId}
        onSelect={(id) => {
          setInteracted(true);
          setSelectedId(id);
        }}
        activeRegionId={activeRegionId}
        onRegionChange={(id) => {
          setInteracted(true);
          setActiveRegionId(id);
          setSelectedId(null);
        }}
      />
    </main>
  );
}
